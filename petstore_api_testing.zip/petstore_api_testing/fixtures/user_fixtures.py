import pytest
from models.user import CreateUser, UserResponse
from clients.user_client import UserClient


@pytest.fixture(scope="function")
def function_user(user_client: UserClient) -> UserResponse:
    """Фикстура: создаёт пользователя для теста и удаляет после"""
    user_data = CreateUser()
    user = user_client.create_user(user_data)
    yield user
    user_client.delete_user(user.username)