import pytest
from models.store import CreateOrder, OrderResponse
from clients.store_client import StoreClient


@pytest.fixture(scope="function")
def function_order(store_client: StoreClient) -> OrderResponse:
    """Фикстура: создаёт заказ для теста и удаляет после"""
    order_data = CreateOrder()
    order = store_client.create_order(order_data)
    yield order
    store_client.delete_order(order.id)