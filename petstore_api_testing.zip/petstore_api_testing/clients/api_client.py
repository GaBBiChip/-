from clients.http_client import HTTPClient
from settings import settings


class APIClient:
    """Базовый класс для работы с API"""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client
        self.base_url = settings.base_url