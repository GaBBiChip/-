import allure
import httpx


class HTTPClient(httpx.Client):
    """Кастомный HTTP-клиент с интеграцией Allure"""

    @allure.step("GET запрос на {url}")
    def get(self, url, **kwargs):
        allure.attach(
            str(kwargs.get("params", "")),
            name="Query Parameters",
            attachment_type=allure.attachment_type.TEXT
        )
        response = super().get(url, **kwargs)
        self._attach_response(response)
        return response

    @allure.step("POST запрос на {url}")
    def post(self, url, **kwargs):
        allure.attach(
            str(kwargs.get("json", kwargs.get("content", ""))),
            name="Request Body",
            attachment_type=allure.attachment_type.JSON
        )
        response = super().post(url, **kwargs)
        self._attach_response(response)
        return response

    @allure.step("PUT запрос на {url}")
    def put(self, url, **kwargs):
        allure.attach(
            str(kwargs.get("json", kwargs.get("content", ""))),
            name="Request Body",
            attachment_type=allure.attachment_type.JSON
        )
        response = super().put(url, **kwargs)
        self._attach_response(response)
        return response

    @allure.step("DELETE запрос на {url}")
    def delete(self, url, **kwargs):
        response = super().delete(url, **kwargs)
        self._attach_response(response)
        return response

    @staticmethod
    def _attach_response(response: httpx.Response):
        allure.attach(
            str(response.status_code),
            name="Status Code",
            attachment_type=allure.attachment_type.TEXT
        )
        if response.text:
            allure.attach(
                response.text,
                name="Response Body",
                attachment_type=allure.attachment_type.JSON
            )