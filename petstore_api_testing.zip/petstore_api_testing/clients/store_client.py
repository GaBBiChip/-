import allure
from clients.api_client import APIClient
from models.store import CreateOrder, UpdateOrder, OrderResponse


class StoreClient(APIClient):

    @allure.step("Создание заказа")
    def create_order(self, order: CreateOrder) -> OrderResponse:
        response = self.http_client.post(
            f"{self.base_url}/store/order",
            json=order.model_dump()
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"
        return OrderResponse(**response.json())

    @allure.step("Получение заказа по id: {order_id}")
    def get_order(self, order_id: int) -> OrderResponse:
        response = self.http_client.get(
            f"{self.base_url}/store/order/{order_id}"
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"
        return OrderResponse(**response.json())

    @allure.step("Обновление заказа: {order_id}")
    def update_order(self, order_id: int, order: UpdateOrder) -> None:
        response = self.http_client.put(
            f"{self.base_url}/store/order/{order_id}",
            json=order.model_dump(exclude_none=True)
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"

    @allure.step("Удаление заказа: {order_id}")
    def delete_order(self, order_id: int) -> None:
        response = self.http_client.delete(
            f"{self.base_url}/store/order/{order_id}"
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"