import allure
from clients.api_client import APIClient
from models.user import CreateUser, UpdateUser, UserResponse


class UserClient(APIClient):

    @allure.step("Создание пользователя")
    def create_user(self, user: CreateUser) -> UserResponse:
        response = self.http_client.post(
            f"{self.base_url}/user",
            json=user.model_dump()
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"
        return UserResponse(**response.json())

    @allure.step("Получение пользователя по username: {username}")
    def get_user(self, username: str) -> UserResponse:
        response = self.http_client.get(
            f"{self.base_url}/user/{username}"
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"
        return UserResponse(**response.json())

    @allure.step("Обновление пользователя: {username}")
    def update_user(self, username: str, user: UpdateUser) -> None:
        response = self.http_client.put(
            f"{self.base_url}/user/{username}",
            json=user.model_dump(exclude_none=True)
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"

    @allure.step("Удаление пользователя: {username}")
    def delete_user(self, username: str) -> None:
        response = self.http_client.delete(
            f"{self.base_url}/user/{username}"
        )
        assert response.status_code == 200, f"Ожидался 200, получен {response.status_code}"