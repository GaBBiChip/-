import pytest
from clients.http_client import HTTPClient
from clients.user_client import UserClient
from clients.store_client import StoreClient
from settings import settings


@pytest.fixture(scope="session")
def http_client():
    """HTTP-клиент на всю сессию тестов"""
    with HTTPClient(
        base_url=settings.base_url,
        headers={"api_key": settings.api_key} if settings.api_key else {}
    ) as client:
        yield client


@pytest.fixture(scope="class")
def user_client(http_client: HTTPClient) -> UserClient:
    return UserClient(http_client)


@pytest.fixture(scope="class")
def store_client(http_client: HTTPClient) -> StoreClient:
    return StoreClient(http_client)


# Подключаем фикстуры
pytest_plugins = [
    "fixtures.user_fixtures",
    "fixtures.store_fixtures",
]