from random import choice, randint
from string import ascii_letters, digits
from datetime import datetime, timedelta


def random_number(start: int = 1, end: int = 10000) -> int:
    return randint(start, end)


def random_string(start: int = 5, end: int = 12) -> str:
    return ''.join(choice(ascii_letters + digits) for _ in range(randint(start, end)))


def random_email() -> str:
    return f"{random_string(5, 8).lower()}@example.com"


def random_phone() -> str:
    return f"+7{randint(1000000000, 9999999999)}"


def random_ship_date() -> str:
    future = datetime.utcnow() + timedelta(days=randint(1, 30))
    return future.strftime("%Y-%m-%dT%H:%M:%S.000Z")