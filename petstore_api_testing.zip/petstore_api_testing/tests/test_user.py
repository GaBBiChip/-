import allure
import pytest
from pydantic import ValidationError

from clients.user_client import UserClient
from models.user import CreateUser, UpdateUser, UserResponse


@allure.feature("User API")
@allure.story("CRUD операции с пользователями")
class TestUserAPI:

    @allure.title("Создание пользователя")
    @allure.description("POST /user — создание нового пользователя с валидацией через Pydantic")
    def test_create_user(self, user_client: UserClient):
        user_data = CreateUser()

        # Автогенерация JSON-схемы модели
        schema = CreateUser.model_json_schema()
        allure.attach(
            str(schema),
            name="JSON Schema модели CreateUser",
            attachment_type=allure.attachment_type.JSON
        )

        # Валидация входных данных через Pydantic
        with allure.step("Валидация модели CreateUser"):
            validated = CreateUser(**user_data.model_dump())
            assert validated.username == user_data.username

        user = user_client.create_user(user_data)

        with allure.step("Проверка ответа через Pydantic-модель"):
            assert isinstance(user, UserResponse)
            assert user.username == user_data.username
            assert user.id == user_data.id

    @allure.title("Получение пользователя")
    @allure.description("GET /user/{username} — получение данных пользователя")
    def test_get_user(self, user_client: UserClient, function_user: UserResponse):
        user = user_client.get_user(function_user.username)

        with allure.step("Валидация ответа через Pydantic"):
            validated = UserResponse(**user.model_dump())
            assert validated.username == function_user.username
            assert validated.id == function_user.id

    @allure.title("Обновление пользователя")
    @allure.description("PUT /user/{username} — обновление данных пользователя")
    def test_update_user(self, user_client: UserClient, function_user: UserResponse):
        update_data = UpdateUser(firstName="UpdatedName")

        # Валидация модели обновления
        with allure.step("Валидация модели UpdateUser"):
            validated = UpdateUser(**update_data.model_dump(exclude_none=True))
            assert validated.firstName == "UpdatedName"

        user_client.update_user(function_user.username, update_data)

        # Проверяем, что обновление прошло
        updated_user = user_client.get_user(function_user.username)
        assert updated_user.firstName == "UpdatedName"

    @allure.title("Удаление пользователя")
    @allure.description("DELETE /user/{username} — удаление пользователя")
    def test_delete_user(self, user_client: UserClient, function_user: UserResponse):
        user_client.delete_user(function_user.username)

        with allure.step("Проверка, что пользователь удалён"):
            response = user_client.http_client.get(
                f"{user_client.base_url}/user/{function_user.username}"
            )
            assert response.status_code == 404, "Пользователь должен быть удалён"