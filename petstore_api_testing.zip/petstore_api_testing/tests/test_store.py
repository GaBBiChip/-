import allure
import pytest

from clients.store_client import StoreClient
from models.store import CreateOrder, UpdateOrder, OrderResponse


@allure.feature("Store API")
@allure.story("CRUD операции с заказами")
class TestStoreAPI:

    @allure.title("Создание заказа")
    @allure.description("POST /store/order — создание нового заказа")
    def test_create_order(self, store_client: StoreClient):
        order_data = CreateOrder()

        # Автогенерация JSON-схемы
        schema = CreateOrder.model_json_schema()
        allure.attach(
            str(schema),
            name="JSON Schema модели CreateOrder",
            attachment_type=allure.attachment_type.JSON
        )

        # Валидация через Pydantic
        with allure.step("Валидация модели CreateOrder"):
            validated = CreateOrder(**order_data.model_dump())
            assert validated.petId == order_data.petId

        order = store_client.create_order(order_data)

        with allure.step("Проверка ответа через Pydantic-модель"):
            assert isinstance(order, OrderResponse)
            assert order.id == order_data.id
            assert order.petId == order_data.petId
            assert order.quantity == order_data.quantity

    @allure.title("Получение заказа")
    @allure.description("GET /store/order/{orderId} — получение заказа по ID")
    def test_get_order(self, store_client: StoreClient, function_order: OrderResponse):
        order = store_client.get_order(function_order.id)

        with allure.step("Валидация ответа через Pydantic"):
            validated = OrderResponse(**order.model_dump())
            assert validated.id == function_order.id
            assert validated.petId == function_order.petId

    @allure.title("Обновление заказа")
    @allure.description("PUT /store/order/{orderId} — обновление заказа")
    def test_update_order(self, store_client: StoreClient, function_order: OrderResponse):
        update_data = UpdateOrder(status="approved", complete=True)

        with allure.step("Валидация модели UpdateOrder"):
            validated = UpdateOrder(**update_data.model_dump(exclude_none=True))
            assert validated.status == "approved"
            assert validated.complete is True

        store_client.update_order(function_order.id, update_data)

        updated_order = store_client.get_order(function_order.id)
        assert updated_order.status == "approved"
        assert updated_order.complete is True

    @allure.title("Удаление заказа")
    @allure.description("DELETE /store/order/{orderId} — удаление заказа")
    def test_delete_order(self, store_client: StoreClient, function_order: OrderResponse):
        store_client.delete_order(function_order.id)

        with allure.step("Проверка, что заказ удалён"):
            response = store_client.http_client.get(
                f"{store_client.base_url}/store/order/{function_order.id}"
            )
            assert response.status_code == 404, "Заказ должен быть удалён"