from typing import Optional, Literal
from pydantic import BaseModel, Field

from utils.fakers import random_number, random_ship_date


OrderStatus = Literal["placed", "approved", "delivered"]


class CreateOrder(BaseModel):
    """Модель для создания заказа"""
    id: int = Field(default_factory=random_number)
    petId: int = Field(default_factory=lambda: random_number(1, 100))
    quantity: int = Field(default_factory=lambda: random_number(1, 10))
    shipDate: str = Field(default_factory=random_ship_date)
    status: OrderStatus = Field(default="placed")
    complete: bool = Field(default=False)


class UpdateOrder(BaseModel):
    """Модель для обновления заказа"""
    petId: Optional[int] = Field(default_factory=lambda: random_number(1, 100))
    quantity: Optional[int] = Field(default_factory=lambda: random_number(1, 10))
    status: Optional[OrderStatus] = Field(default="approved")
    complete: Optional[bool] = Field(default=True)


class OrderResponse(BaseModel):
    """Модель ответа API для Order"""
    id: int
    petId: int
    quantity: int
    shipDate: Optional[str] = None
    status: Optional[OrderStatus] = None
    complete: Optional[bool] = None