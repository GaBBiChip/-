from typing import Optional
from pydantic import BaseModel, Field

from utils.fakers import random_string, random_email, random_phone, random_number


class CreateUser(BaseModel):
    """Модель для создания пользователя"""
    id: int = Field(default_factory=random_number)
    username: str = Field(default_factory=lambda: random_string(6, 10))
    firstName: Optional[str] = Field(default_factory=lambda: random_string(5, 8))
    lastName: Optional[str] = Field(default_factory=lambda: random_string(5, 8))
    email: str = Field(default_factory=random_email)
    password: str = Field(default_factory=lambda: random_string(8, 12))
    phone: str = Field(default_factory=random_phone)
    userStatus: int = Field(default=0, description="User Status: 0-active, 1-inactive")


class UpdateUser(BaseModel):
    """Модель для обновления пользователя"""
    firstName: Optional[str] = Field(default_factory=lambda: random_string(5, 8))
    lastName: Optional[str] = Field(default_factory=lambda: random_string(5, 8))
    email: Optional[str] = Field(default_factory=random_email)
    phone: Optional[str] = Field(default_factory=random_phone)
    userStatus: Optional[int] = Field(default=1)


class UserResponse(BaseModel):
    """Модель ответа API для User"""
    id: int
    username: str
    firstName: Optional[str] = None
    lastName: Optional[str] = None
    email: Optional[str] = None
    password: Optional[str] = None
    phone: Optional[str] = None
    userStatus: Optional[int] = None


class UserList(BaseModel):
    """Модель списка пользователей"""
    root: list[UserResponse]